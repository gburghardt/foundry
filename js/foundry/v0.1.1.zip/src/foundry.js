var Foundry = {
	version: "0.1.1"
};
